🚀 Pullout System by Script Lab
Version: 1.1.0
Entwickler: Script Lab
Discord-Support: https://discord.gg/Te2B9AW86R

📜 Beschreibung
Dieses Skript ermöglicht es, bewusstlose Spieler aus Fahrzeugen zu ziehen. Zusätzlich können mit dem Befehl /id die Spieler-IDs von Spielern im Umkreis von 2 Metern angezeigt werden.

📂 Installation
Dateien hochladen:

Lade den pullout-Ordner in den resources-Ordner deines FiveM-Servers.
Server.cfg bearbeiten:

Füge folgende Zeile in die server.cfg ein:

ensure sl_pullout

Server neustarten:

Starte den Server neu oder verwende den Befehl: Restart sl_pullout


🕹️ Befehle

/id : Zeigt für 5 Sekunden die Spieler-IDs im Umkreis von 2 Metern an.

/pullout : Zieht einen bewusstlosen Spieler mit der angegebenen ID aus einem Fahrzeug. Falls keine ID angegeben ist, wird automatisch im Fahrzeug nach bewusstlosen Spielern gesucht.



⚠️ Nutzungsbedingungen
Das Skript darf nicht ohne vorherige Genehmigung verändert oder weiterverkauft werden.
Jegliche Weitergabe oder Veröffentlichung ohne Erlaubnis ist strengstens untersagt.
Support oder Anpassungen gibt es nur über den offiziellen Discord.