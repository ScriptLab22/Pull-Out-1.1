RegisterNetEvent("removeUnconsciousPlayer")
AddEventHandler("removeUnconsciousPlayer", function()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
       -- print("Removing unconscious player from vehicle...")
        local vehicle = GetVehiclePedIsIn(ped, false)
        TaskLeaveVehicle(ped, vehicle, 16)
        Wait(500)
        if IsPedInAnyVehicle(ped, false) then
           -- print("TaskLeaveVehicle failed, forcing teleport...")
            SetPedIntoVehicle(ped, vehicle, -1)
            Wait(100)
            ClearPedTasksImmediately(ped)
            SetEntityCoords(ped, GetEntityCoords(vehicle) + vector3(2, 0, 0))
        end
    else
        --print("Player is not in a vehicle.")
    end
end)

RegisterNetEvent("findAndRemoveUnconscious")
AddEventHandler("findAndRemoveUnconscious", function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    if vehicle then
       -- print("Searching for unconscious players in vehicle...")
        for i = -1, GetVehicleMaxNumberOfPassengers(vehicle) - 1 do
            local occupant = GetPedInVehicleSeat(vehicle, i)
            if occupant and occupant ~= playerPed and IsPedDeadOrDying(occupant, true) then
                --print("Found unconscious player, pulling out...")
                TaskLeaveVehicle(occupant, vehicle, 16)
                Wait(500)
                if IsPedInAnyVehicle(occupant, false) then
                   -- print("TaskLeaveVehicle failed, forcing teleport...")
                    SetPedIntoVehicle(occupant, vehicle, -1)
                    Wait(100)
                    ClearPedTasksImmediately(occupant)
                    SetEntityCoords(occupant, GetEntityCoords(vehicle) + vector3(2, 0, 0))
                end
                return
            end
        end
        --print("No unconscious player found in vehicle.")
    else
       -- print("Player is not in a vehicle.")
    end
end)

RegisterNetEvent("showNearbyIDs")
AddEventHandler("showNearbyIDs", function(players)
    for _, player in ipairs(players) do
        local ped = GetPlayerPed(GetPlayerFromServerId(player.id))
        if DoesEntityExist(ped) then
            local coords = GetEntityCoords(ped)
            local playerCoords = GetEntityCoords(PlayerPedId())
            if #(playerCoords - coords) <= 2.0 then
                --print("Spieler ID: " .. player.id .. " Name: " .. player.name)
            end
        end
    end
    Wait(5000)
end)

RegisterNetEvent("showNearbyPlayerIDs")
AddEventHandler("showNearbyPlayerIDs", function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    for _, playerId in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(playerId)
        local targetCoords = GetEntityCoords(targetPed)

        if #(playerCoords - targetCoords) <= 2.0 then -- Spieler im Umkreis von 5 Metern
            TriggerEvent('esx:showNotification', "Spieler in deiner Nähe: ID " .. GetPlayerServerId(playerId))
        end
    end

    -- Warte 5 Sekunden und lösche die IDs
    Citizen.Wait(5000)
end)

