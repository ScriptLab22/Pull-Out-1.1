fx_version 'cerulan'
game 'gta5'

author 'Script Lab'
description 'Pulling unconscious players out of vehicles'
version '1.0'

client_script 'client.lua'
server_script 'server.lua'