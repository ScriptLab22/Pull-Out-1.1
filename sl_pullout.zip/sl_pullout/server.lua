ESX = nil
ESX = exports["es_extended"]:getSharedObject()

Citizen.CreateThread(function()
    print([[
 _____              _         _     _             _     
/  ___|            (_)       | |   | |           | |    
\ `--.   ___  _ __  _  _ __  | |_  | |      __ _ | |__  
 `--. \ / __|| '__|| || '_ \ | __| | |     / _` || '_ \ 
/\__/ /| (__ | |   | || |_) || |_  | |____| (_| || |_) |
\____/  \___||_|   |_|| .__/  \__| \_____/ \__,_||_.__/ 
                      | |                               
                      |_|                               
______         _  _  _____         _                    
| ___ \       | || ||  _  |       | |                   
| |_/ / _   _ | || || | | | _   _ | |_                  
|  __/ | | | || || || | | || | | || __|                 
| |    | |_| || || |\ \_/ /| |_| || |_                  
\_|     \__,_||_||_| \___/  \__,_| \__|                 
                                       
    ───────────────────────────────────────────────────
      🎟️ Pull Out SYSTEM 
      ✅ Developed by: Script Lab
      🔗 Support: https://discord.gg/Te2B9AW86R
      📅 Version: 1.1.0  
    ───────────────────────────────────────────────────
    
    ]])
end)
RegisterCommand("pullout", function(source, args)
    local targetId = tonumber(args[1])
    if targetId then
        --print("Pulling out player with ID: " .. targetId)
        TriggerClientEvent("removeUnconsciousPlayer", targetId)
    else
        --print("No ID given, searching for unconscious players...")
        TriggerClientEvent("findAndRemoveUnconscious", source)
    end
end, false)

RegisterCommand("id", function(source, args)
    local players = {}
    local xPlayer = ESX.GetPlayerFromId(source)
    local playerCoords = xPlayer.getCoords()

    for _, player in ipairs(GetPlayers()) do
        local targetXPlayer = ESX.GetPlayerFromId(player)
        if targetXPlayer then
            local targetCoords = targetXPlayer.getCoords()
            if #(vector3(playerCoords.x, playerCoords.y, playerCoords.z) - vector3(targetCoords.x, targetCoords.y, targetCoords.z)) <= 5.0 then

                table.insert(players, { id = player, name = targetXPlayer.getName() })
            end
        end
    end

    TriggerClientEvent("showNearbyIDs", source, players)
end, false)
RegisterCommand("id", function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    TriggerClientEvent("showNearbyPlayerIDs", source)
end, false)

